# train_many.py
import random, numpy as np, torch
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import f1_score
import matplotlib.pyplot as plt
from pathlib import Path
from typing import Sequence
from typing import Union

from registry import REGISTRY
from datamod import prepare_dataset
from models import build_model
from schemas import DatasetSchema

# -------------------
# 재현성: 시드 고정
# -------------------
def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# -------------------
# 유틸
# -------------------
def _to_tensor(X: np.ndarray, y: np.ndarray, device=None, dtype=torch.float32):
    X_t = torch.as_tensor(X, dtype=dtype, device=device)
    y_t = torch.as_tensor(y, dtype=torch.long,  device=device)
    return X_t, y_t

def accuracy_from_logits(logits: torch.Tensor, targets: torch.Tensor) -> float:
    preds = logits.argmax(dim=1)
    return (preds == targets).float().mean().item()

def predict_labels(model: torch.nn.Module, X: torch.Tensor) -> np.ndarray:
    model.eval()
    with torch.no_grad():
        logits = model(X)
        preds = logits.argmax(dim=1).cpu().numpy()
    return preds

# -------------------
# 학습 루프(경사하강법 포함 + EarlyStopping)
# -------------------
def train(
    model: torch.nn.Module,
    X_train: np.ndarray, y_train: np.ndarray,
    X_val:   np.ndarray, y_val:   np.ndarray,
    loss_fn,
    epochs: int = 50,
    batch_size: int = 64,
    lr: float = 1e-3,
    weight_decay: float = 1e-4,
    optimizer_name: str = "adam",    # "adam" | "sgd"
    patience: int = 10,
    device: str | None = None,
    dtype = torch.float32,
):
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device=device, dtype=dtype)

    Xtr_t, ytr_t = _to_tensor(X_train, y_train, device=device, dtype=dtype)
    Xva_t, yva_t = _to_tensor(X_val,   y_val,   device=device, dtype=dtype)

    train_loader = DataLoader(TensorDataset(Xtr_t, ytr_t), batch_size=batch_size, shuffle=True)

    if optimizer_name.lower() == "sgd":
        optimizer = torch.optim.SGD(model.parameters(), lr=lr, weight_decay=weight_decay, momentum=0.9)
    else:
        optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

    history = {"train_loss": [], "val_loss": [], "val_acc": [], "val_f1": []}

    best_val = float("inf")
    best_state = None
    wait = 0

    for ep in range(1, epochs + 1):
        # ---- train ----
        model.train()
        total = 0.0
        for xb, yb in train_loader:
            optimizer.zero_grad(set_to_none=True)
            logits = model(xb)
            loss = loss_fn(logits, yb)
            loss.backward()
            optimizer.step()
            total += loss.item() * xb.size(0)
        train_loss = total / len(train_loader.dataset)

        # ---- validate ----
        model.eval()
        with torch.no_grad():
            val_logits = model(Xva_t)
            val_loss = loss_fn(val_logits, yva_t).item()
            val_acc  = accuracy_from_logits(val_logits, yva_t)
            y_pred = val_logits.argmax(dim=1).cpu().numpy()
            y_true = yva_t.cpu().numpy()
            val_f1 = f1_score(y_true, y_pred, average="macro")

        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["val_acc"].append(val_acc)
        history["val_f1"].append(val_f1)

        print(f"[{ep:03d}/{epochs}] train_loss={train_loss:.4f}  val_loss={val_loss:.4f}  "
              f"val_acc={val_acc:.4f}  val_f1={val_f1:.4f}")

        # Early Stopping
        if val_loss < best_val - 1e-8:
            best_val = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                print(f"Early stopping at epoch {ep}")
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    return history

# -------------------
# 그래프 유틸
# -------------------
def plot_history(histories: Sequence[dict], labels: Sequence[str],
                 title_suffix: str = "", outdir: str | Path = "plots",
                 show: bool = True, close: bool = True):
    assert len(histories) == len(labels)
    outdir = Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    def _save_show(path):
        plt.savefig(path, dpi=150, bbox_inches="tight")
        if show: plt.show()
        if close: plt.close()

    # Val Acc
    plt.figure(figsize=(7,5))
    for h, lab in zip(histories, labels): plt.plot(h["val_acc"], label=lab)
    plt.xlabel("Epoch"); plt.ylabel("Validation Accuracy"); plt.title(f"Validation Accuracy {title_suffix}")
    plt.grid(True, alpha=0.3); plt.legend()
    _save_show(outdir / f"val_acc{('_' + title_suffix.replace(' ', '_')) if title_suffix else ''}.png")

    # Val Loss
    plt.figure(figsize=(7,5))
    for h, lab in zip(histories, labels): plt.plot(h["val_loss"], label=lab)
    plt.xlabel("Epoch"); plt.ylabel("Validation Loss"); plt.title(f"Validation Loss {title_suffix}")
    plt.grid(True, alpha=0.3); plt.legend()
    _save_show(outdir / f"val_loss{('_' + title_suffix.replace(' ', '_')) if title_suffix else ''}.png")

    # Train Loss
    plt.figure(figsize=(7,5))
    for h, lab in zip(histories, labels): plt.plot(h["train_loss"], label=lab)
    plt.xlabel("Epoch"); plt.ylabel("Train Loss"); plt.title(f"Train Loss {title_suffix}")
    plt.grid(True, alpha=0.3); plt.legend()
    _save_show(outdir / f"train_loss{('_' + title_suffix.replace(' ', '_')) if title_suffix else ''}.png")

# -------------------
# 하이퍼 추천(옵션)
# -------------------
def suggest_hparams(num_train: int, dim: int | None = None, noisy: bool = False):
    if num_train <= 2_000:    cfg = dict(batch_size=32,  epochs=100, lr=1e-3, patience=15)
    elif num_train <= 20_000: cfg = dict(batch_size=64,  epochs=60,  lr=1e-3, patience=10)
    elif num_train <= 200_000:cfg = dict(batch_size=128, epochs=40,  lr=8e-4, patience=7)
    else:                     cfg = dict(batch_size=256, epochs=20,  lr=5e-4, patience=5)
    if dim is not None and dim > 500:
        cfg["weight_decay"] = 3e-4
    if noisy:
        cfg["epochs"] = int(cfg["epochs"] * 0.8)
    return cfg

# -------------------
# 실험 오케스트레이션
# -------------------
def run_experiment(
    df,
    schema_or_name: Union[str, DatasetSchema],
    loss_fn,
    # 고정 기본값 (공정비교 프리셋)
    epochs: int = 50,
    batch_size: int = 64,
    lr: float = 1e-3,
    weight_decay: float = 1e-4,
    optimizer_name: str = "adam",
    loss_name: str = "loss",
    patience: int = 10,
    seed: int = 42,
    device: str | None = None,
):
    set_seed(seed)

    # 이름이면 REGISTRY에서 찾고, 객체면 그대로 사용
    if isinstance(schema_or_name, str):
        from registry import REGISTRY # 필요할 때만 import
        schema = REGISTRY[schema_or_name]
    else:
        schema = schema_or_name
        
    (Xtr, ytr), (Xval, yval), (Xte, yte), meta = prepare_dataset(df, schema, random_state=seed)

    # 필요 시 자동 추천으로 덮어쓰기 예시:
    # auto = suggest_hparams(num_train=len(Xtr), dim=meta["n_features"])
    # epochs = epochs or auto["epochs"]; batch_size = batch_size or auto["batch_size"]; lr = lr or auto["lr"]; patience = patience or auto["patience"]

    model = build_model(meta["n_features"], meta["num_classes"])

    # 학습 시작 알림
    print(f"{loss_name.upper()} training start...")

    hist = train(
        model, Xtr, ytr, Xval, yval,
        loss_fn=loss_fn,
        epochs=epochs, batch_size=batch_size,
        lr=lr, weight_decay=weight_decay,
        optimizer_name=optimizer_name, patience=patience,
        device=device
    )

    # 최종 테스트 평가
    Xte_t, yte_t = _to_tensor(Xte, yte, device=device or ("cuda" if torch.cuda.is_available() else "cpu"))
    model.eval()
    with torch.no_grad():
        logits = model(Xte_t)
        test_acc = accuracy_from_logits(logits, yte_t)
        y_pred = logits.argmax(dim=1).cpu().numpy()
        y_true = yte_t.cpu().numpy()
        test_f1 = f1_score(y_true, y_pred, average="macro")
    
    print(f"\n{loss_name.upper()}\n [TEST] acc={test_acc:.4f}  f1_macro={test_f1:.4f}\n")
    return model, hist, dict(test_acc=test_acc, test_f1=test_f1)
